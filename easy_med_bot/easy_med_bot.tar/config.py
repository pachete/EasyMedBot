# API_TOKEN = '1294627568:AAFVVUncrrbbEQ1MOJmeytYt5tyseJxjmFE'
API_TOKEN = '941290827:AAGEGFB-ZdhJyNRkwsCiD17T_8ZxfFatRXs'

commands = ["start", "help", "register"]
steps = ["STEP1", "STEP2", "STEP3"]
years = [["2014", "2015", "2016", "2017", "2018"], ["2017", "2018"], ["2019"]]

tasks_dict = dict()
user_dict = dict()

reply_keyboard_markup = None
