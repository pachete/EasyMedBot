import telebot
from easy_med_bot import config

easy_med_bot = telebot.TeleBot(config.API_TOKEN)
